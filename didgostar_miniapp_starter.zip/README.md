# Didgostar Telegram Mini App — Starter

This is a starter project for the Didgostar security-equipment Telegram Mini App.

## What is included
- Telegram Mini App frontend (HTML/CSS/JavaScript)
- FastAPI backend
- SQLite product/order storage
- Customer / partner account mode (partner activation is admin-controlled)
- Product catalog, search, cart, order submission
- Telegram WebApp `initData` verification on the backend
- Demo products for cameras, DVR/NVR, alarms and networking

## Requirements
- Python 3.10+
- A public HTTPS domain for Telegram Mini Apps
- A Telegram bot token from @BotFather (keep it private)

## 1. Configure
Copy `.env.example` to `.env` and set:
- `BOT_TOKEN`: token from @BotFather
- `ADMIN_TELEGRAM_IDS`: comma-separated Telegram numeric user IDs that can administer the app
- `PUBLIC_BASE_URL`: your HTTPS domain, e.g. `https://shop.example.com`

Never share your bot token in chat or commit it to source control.

## 2. Install and run locally
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```
Open `http://127.0.0.1:8000` for a browser preview. Telegram requires HTTPS for the deployed Mini App.

## 3. Connect the Mini App to BotFather
After deploying the app to a public HTTPS URL:
1. Open @BotFather
2. Select `/mybots` → `@didgostar_AIBOT`
3. Open `Bot Settings` → `Configure Mini App` (or the current Mini App menu option)
4. Set the deployed HTTPS URL.
5. Add a menu button / Web App button if offered by BotFather.

BotFather's menu labels can change. Use the Mini Apps documentation:
https://core.telegram.org/bots/webapps

## 4. Deploy
Deploy this project to a Python host that supports HTTPS and persistent storage.
For production, use PostgreSQL instead of SQLite, configure backups, HTTPS, logging,
rate limits, and a proper admin interface. SQLite is used here only to make the starter
easy to run.

## Important security notes
- The backend verifies Telegram `initData` when `BOT_TOKEN` is configured.
- Do not trust client-side prices or role values. The backend calculates order totals
  from database prices and checks partner approval.
- Partner approval is represented by `is_partner` in the database. A real admin
  workflow/UI still needs to be added.
- Payment gateway integration is not included. Orders are created as `pending`.
- The sample admin endpoints require Telegram IDs listed in `ADMIN_TELEGRAM_IDS`.
- For live deployment, add HTTPS, database backups, CSRF/origin protections where
  applicable, monitoring, and a production ASGI server setup.

## First test
The database seeds demo products automatically. Start the server, open the page,
add a product to cart, and submit a test order. Without Telegram, the app runs in
preview mode using a demo user. Do not enable preview mode on a public production site.
