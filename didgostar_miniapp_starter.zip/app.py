import os, json, hmac, hashlib, secrets, sqlite3, time
from urllib.parse import parse_qsl
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = {x.strip() for x in os.getenv("ADMIN_TELEGRAM_IDS", "").split(",") if x.strip()}
ALLOW_PREVIEW = os.getenv("ALLOW_BROWSER_PREVIEW", "false").lower() == "true"
DB = Path(__file__).with_name("didgostar.db")
app = FastAPI(title="Didgostar Mini App API")
app.mount("/static", StaticFiles(directory="static"), name="static")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users (
            telegram_id TEXT PRIMARY KEY, first_name TEXT, username TEXT,
            is_partner INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            category TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            retail_price INTEGER NOT NULL, partner_price INTEGER NOT NULL,
            stock INTEGER NOT NULL DEFAULT 0, image_url TEXT NOT NULL DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1)""")
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id TEXT NOT NULL,
            customer_name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL,
            items_json TEXT NOT NULL, total INTEGER NOT NULL, status TEXT NOT NULL,
            created_at INTEGER NOT NULL)""")
        count = con.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if count == 0:
            demo = [
                ("دوربین بولت ۲ مگاپیکسل","دوربین مداربسته","دوربین مناسب فضای داخلی و بیرونی؛ مشخصات نمونه را با کالای واقعی جایگزین کنید.",3500000,3100000,20,""),
                ("دوربین دام ۴ مگاپیکسل","دوربین مداربسته","دوربین دام با کیفیت تصویر ۴ مگاپیکسل؛ مشخصات نهایی وابسته به مدل است.",5200000,4700000,12,""),
                ("دستگاه ضبط ۸ کانال","DVR و NVR","دستگاه ضبط تصویر ۸ کانال؛ مدل و قابلیت‌ها را پیش از فروش بررسی کنید.",8900000,8200000,8,""),
                ("دزدگیر اماکن","دزدگیر اماکن","پکیج نمونه دزدگیر اماکن؛ اقلام داخل جعبه را دقیق درج کنید.",7800000,7100000,10,""),
                ("سوئیچ شبکه ۸ پورت","تجهیزات شبکه","سوئیچ شبکه ۸ پورت؛ نوع مدیریتی یا غیرمدیریتی را مشخص کنید.",2400000,2150000,15,"")
            ]
            con.executemany("""INSERT INTO products
                (title,category,description,retail_price,partner_price,stock,image_url)
                VALUES (?,?,?,?,?,?,?)""", demo)

init_db()

def verify_init_data(init_data: str):
    if not BOT_TOKEN:
        if ALLOW_PREVIEW:
            return {"id": "preview-user", "first_name": "کاربر آزمایشی", "username": "preview"}
        raise HTTPException(503, "Telegram bot is not configured")
    if not init_data:
        raise HTTPException(401, "Telegram initData is required")
    data = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = data.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "Invalid Telegram data")
    check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise HTTPException(401, "Telegram data verification failed")
    auth_date = int(data.get("auth_date", "0"))
    if time.time() - auth_date > 86400:
        raise HTTPException(401, "Telegram session expired")
    user = json.loads(data.get("user", "{}"))
    if not user.get("id"):
        raise HTTPException(401, "Telegram user missing")
    return user

def current_user(authorization: Optional[str]):
    raw = (authorization or "").removeprefix("tma ").strip()
    user = verify_init_data(raw)
    tid = str(user["id"])
    with db() as con:
        con.execute("""INSERT OR IGNORE INTO users
            (telegram_id,first_name,username,created_at) VALUES (?,?,?,?)""",
            (tid, user.get("first_name",""), user.get("username",""), int(time.time())))
        row = con.execute("SELECT * FROM users WHERE telegram_id=?", (tid,)).fetchone()
    return user, row

class OrderIn(BaseModel):
    customer_name: str = Field(min_length=2, max_length=100)
    phone: str = Field(min_length=6, max_length=30)
    address: str = Field(min_length=5, max_length=500)
    items: list[dict]

class ProductIn(BaseModel):
    title: str
    category: str
    description: str = ""
    retail_price: int
    partner_price: int
    stock: int = 0
    image_url: str = ""

@app.get("/", response_class=HTMLResponse)
def home():
    return Path("static/index.html").read_text(encoding="utf-8")

@app.get("/api/me")
def me(authorization: Optional[str] = Header(default=None)):
    user, row = current_user(authorization)
    return {"telegram_id": str(user["id"]), "first_name": user.get("first_name",""),
            "username": user.get("username",""), "is_partner": bool(row["is_partner"])}

@app.get("/api/products")
def products(authorization: Optional[str] = Header(default=None)):
    user, row = current_user(authorization)
    with db() as con:
        rows = con.execute("SELECT * FROM products WHERE active=1 ORDER BY id DESC").fetchall()
    is_partner = bool(row["is_partner"])
    return [{"id":p["id"],"title":p["title"],"category":p["category"],
             "description":p["description"],
             "price":p["partner_price"] if is_partner else p["retail_price"],
             "retail_price":p["retail_price"] if is_partner else None,
             "stock":p["stock"],"image_url":p["image_url"]} for p in rows]

@app.post("/api/orders")
def create_order(order: OrderIn, authorization: Optional[str] = Header(default=None)):
    user, row = current_user(authorization)
    if not order.items:
        raise HTTPException(400, "سبد خرید خالی است")
    is_partner = bool(row["is_partner"])
    clean, total = [], 0
    with db() as con:
        for item in order.items:
            try:
                pid, qty = int(item["product_id"]), int(item["quantity"])
            except Exception:
                raise HTTPException(400, "قلم سفارش نامعتبر است")
            if qty < 1 or qty > 100:
                raise HTTPException(400, "تعداد نامعتبر است")
            p = con.execute("SELECT * FROM products WHERE id=? AND active=1", (pid,)).fetchone()
            if not p or p["stock"] < qty:
                raise HTTPException(400, "محصول موجود نیست یا موجودی کافی نیست")
            price = p["partner_price"] if is_partner else p["retail_price"]
            total += price * qty
            clean.append({"product_id":pid,"title":p["title"],"quantity":qty,"unit_price":price})
        cur = con.execute("""INSERT INTO orders
            (telegram_id,customer_name,phone,address,items_json,total,status,created_at)
            VALUES (?,?,?,?,?,?,?,?)""",
            (str(user["id"]),order.customer_name,order.phone,order.address,
             json.dumps(clean,ensure_ascii=False),total,"pending",int(time.time())))
        order_id = cur.lastrowid
    return {"ok":True,"order_id":order_id,"total":total,"status":"pending"}

def require_admin(authorization):
    user, _ = current_user(authorization)
    if str(user["id"]) not in ADMIN_IDS:
        raise HTTPException(403, "مدیر مجاز نیست")
    return user

@app.get("/api/admin/orders")
def admin_orders(authorization: Optional[str] = Header(default=None)):
    require_admin(authorization)
    with db() as con:
        rows = con.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 200").fetchall()
    return [dict(r) for r in rows]

@app.post("/api/admin/products")
def add_product(p: ProductIn, authorization: Optional[str] = Header(default=None)):
    require_admin(authorization)
    if p.retail_price < 0 or p.partner_price < 0 or p.stock < 0:
        raise HTTPException(400, "قیمت یا موجودی نامعتبر است")
    with db() as con:
        cur = con.execute("""INSERT INTO products
            (title,category,description,retail_price,partner_price,stock,image_url)
            VALUES (?,?,?,?,?,?,?)""",
            (p.title,p.category,p.description,p.retail_price,p.partner_price,p.stock,p.image_url))
    return {"ok":True,"product_id":cur.lastrowid}

@app.post("/api/admin/partners/{telegram_id}/approve")
def approve_partner(telegram_id: str, authorization: Optional[str] = Header(default=None)):
    require_admin(authorization)
    with db() as con:
        cur = con.execute("UPDATE users SET is_partner=1 WHERE telegram_id=?", (telegram_id,))
    if cur.rowcount == 0:
        raise HTTPException(404, "کاربر پیدا نشد")
    return {"ok":True}
