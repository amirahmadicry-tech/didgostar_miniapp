const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); }
const initData = tg?.initData || "";
const headers = initData ? {"Authorization":"tma "+initData} : {};
const fmt = n => new Intl.NumberFormat("fa-IR").format(n) + " تومان";
let products=[], cart={}, category="همه", isPartner=false;
const cats=["همه","دوربین مداربسته","DVR و NVR","دزدگیر اماکن","تجهیزات شبکه"];
function toast(t){const el=document.getElementById("toast");el.textContent=t;el.style.display="block";setTimeout(()=>el.style.display="none",2300)}
async function api(path,opts={}) {
  const r=await fetch(path,{...opts,headers:{...headers,...(opts.headers||{})}});
  const d=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(d.detail||"خطا در ارتباط با سرور");
  return d;
}
function drawCats(){
  document.getElementById("categories").innerHTML=cats.map(c=>`<button class="cat ${c===category?'active':''}" data-cat="${c}">${c}</button>`).join("");
  document.querySelectorAll(".cat").forEach(b=>b.onclick=()=>{category=b.dataset.cat;drawCats();drawProducts()});
}
function drawProducts(){
  const q=document.getElementById("search").value.trim().toLowerCase();
  const list=products.filter(p=>(category==="همه"||p.category===category)&&(`${p.title} ${p.category}`.toLowerCase().includes(q)));
  document.getElementById("count").textContent= list.length+" کالا";
  document.getElementById("products").innerHTML=list.map(p=>`<article class="product">
    <div class="pic">${p.image_url?`<img src="${p.image_url}" style="max-width:100%;max-height:100%;object-fit:contain">`:"📷"}</div>
    <h3>${p.title}</h3><p>${p.description}</p><div class="price">${fmt(p.price)}</div>
    <div class="stock">موجودی: ${new Intl.NumberFormat("fa-IR").format(p.stock)}</div>
    <button class="add" data-add="${p.id}">افزودن به سبد</button></article>`).join("")||"<p>محصولی پیدا نشد.</p>";
  document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>{const id=Number(b.dataset.add);cart[id]=(cart[id]||0)+1;updateCart();toast("به سبد خرید اضافه شد")});
}
function updateCart(){
  const count=Object.values(cart).reduce((a,b)=>a+b,0);
  document.getElementById("cartCount").textContent=new Intl.NumberFormat("fa-IR").format(count);
}
function showCart(){
  const rows=Object.entries(cart).map(([id,qty])=>{const p=products.find(x=>x.id===Number(id));return p?{p,qty}:null}).filter(Boolean);
  document.getElementById("cartItems").innerHTML=rows.map(({p,qty})=>`<div class="cart-row"><div>${p.title}<br><small>${fmt(p.price)}</small></div><div class="qty"><button data-dec="${p.id}">−</button> ${qty} <button data-inc="${p.id}">+</button></div></div>`).join("")||"<p>سبد خرید خالی است.</p>";
  const total=rows.reduce((s,x)=>s+x.p.price*x.qty,0);
  document.getElementById("cartTotal").textContent=fmt(total);
  document.querySelectorAll("[data-dec]").forEach(b=>b.onclick=()=>{const id=b.dataset.dec;cart[id]--;if(cart[id]<=0)delete cart[id];updateCart();showCart()});
  document.querySelectorAll("[data-inc]").forEach(b=>b.onclick=()=>{cart[b.dataset.inc]++;updateCart();showCart()});
  document.getElementById("orderResult").textContent="";
  document.getElementById("cartDialog").showModal();
}
async function start(){
  try{
    const me=await api("/api/me");
    isPartner=me.is_partner;
    document.getElementById("welcome").textContent="سلام "+(me.first_name||"دوست عزیز")+"، خوش آمدید";
    document.getElementById("role").textContent=isPartner?"حساب همکار تأییدشده":"حساب مشتری عادی";
    products=await api("/api/products");
    drawCats();drawProducts();
  }catch(e){
    document.getElementById("role").textContent=e.message;
    document.getElementById("products").innerHTML="<p style='padding:12px'>برای استفاده واقعی، ربات و سرور باید پیکربندی شوند. در پیش‌نمایش محلی، حالت آزمایشی را فعال کنید.</p>";
  }
}
document.getElementById("search").addEventListener("input",drawProducts);
document.getElementById("cartButton").onclick=showCart;
document.getElementById("closeCart").onclick=()=>document.getElementById("cartDialog").close();
document.getElementById("orderForm").onsubmit=async e=>{
  e.preventDefault();
  const items=Object.entries(cart).map(([product_id,quantity])=>({product_id:Number(product_id),quantity}));
  if(!items.length){toast("سبد خرید خالی است");return}
  const f=new FormData(e.target);
  try{
    const result=await api("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
      customer_name:f.get("customer_name"),phone:f.get("phone"),address:f.get("address"),items
    })});
    document.getElementById("orderResult").textContent=`سفارش شما با شماره ${new Intl.NumberFormat("fa-IR").format(result.order_id)} ثبت شد. مبلغ: ${fmt(result.total)}. سفارش در انتظار تأیید است.`;
    cart={};updateCart();document.getElementById("cartItems").innerHTML="";document.getElementById("cartTotal").textContent=fmt(0);e.target.reset();
  }catch(err){document.getElementById("orderResult").textContent=err.message}
};
start();
